var num1Input = document.getElementById('num1');
var num2Input = document.getElementById('num2');
var num3Input = document.getElementById('num3');
var resultadoPara = document.getElementById('resultado');

function obterMaiorNumero(num1, num2, num3) {
    return Math.max(num1, num2, num3);
}

function ordenarCrescente(num1, num2, num3) {
    var numeros = [num1, num2, num3];
    numeros.sort(function(a, b) { return a - b; });
    return numeros.join(', ');
}

function verificarPalindromo(palavra) {
    var reversed = palavra.split('').reverse().join('');
    return palavra === reversed;
}

function verificarTipoTriangulo(a, b, c) {
    if (a === b && b === c) {
        return 'equilátero';
    } else if (a === b || a === c || b === c) {
        return 'isósceles';
    } else {
        return 'escaleno';
    }
}

function verificarTriangulo() {
    var num1 = parseFloat(num1Input.value);
    var num2 = parseFloat(num2Input.value);
    var num3 = parseFloat(num3Input.value);

    if (num1 + num2 > num3 && num1 + num3 > num2 && num2 + num3 > num1) {
        var tipo = verificarTipoTriangulo(num1, num2, num3);
        return 'Forma um triângulo ' + tipo;
    } else {
        return 'Não forma um triângulo';
    }
}

function exibirResultado(resultado) {
    resultadoPara.innerText = resultado;
}

document.getElementById('btnMaiorNumero').addEventListener('click', function() {
    var num1 = parseFloat(num1Input.value);
    var num2 = parseFloat(num2Input.value);
    var num3 = parseFloat(num3Input.value);
    var maior = obterMaiorNumero(num1, num2, num3);
    exibirResultado('O maior número é: ' + maior);
});

document.getElementById('btnOrdemCrescente').addEventListener('click', function() {
    var num1 = parseFloat(num1Input.value);
    var num2 = parseFloat(num2Input.value);
    var num3 = parseFloat(num3Input.value);
    var ordenados = ordenarCrescente(num1, num2, num3);
    exibirResultado('Em ordem crescente: ' + ordenados);
});

document.getElementById('btnPalindromo').addEventListener('click', function() {
    var palavra = num1Input.value.toLowerCase();
    var palindromo = verificarPalindromo(palavra);
    if (palindromo) {
        exibirResultado('É um palíndromo!');
    } else {
        exibirResultado('Não é um palíndromo!');
    }
});

document.getElementById('btnTipoTriangulo').addEventListener('click', function() {
    var resultado = verificarTriangulo();
    exibirResultado(resultado);
});
