function abrirJanela() {
    document.getElementById('janela').style.backgroundImage = "url('./img/janela-aberta.png')";
    document.getElementById('event').textContent = "Janela Aberta.";
  }

  function fecharJanela() {
    document.getElementById('janela').style.backgroundImage = "url('./img/janela.png')";
    document.getElementById('event').textContent = "Janela Fechada.";
  }

  function quebrarJanela() {
    document.getElementById('janela').style.backgroundImage = "url('./img/janela-quebrada.png')";
    document.getElementById('event').textContent = "Janela Quebrada!";
  }