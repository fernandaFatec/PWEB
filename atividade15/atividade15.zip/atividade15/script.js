function validar() {
    var form = document.pesquisaForm;
    var nome = form.elements['nome'].value.trim();
    var email = form.elements['email'].value.trim();
    var comentario = form.elements['comentario'].value.trim();
    var pesquisa = form.elements['pesquisa'];
    var pesquisaEscolhida = false;
    var mensagem = '';

    if (nome.length < 10) {
        alert('O nome deve ter pelo menos 10 caracteres.');
        form.elements['nome'].focus();
        return false;
    }

    if (!email.includes('@') || !email.includes('.')) {
        alert('Por favor, insira um endereço de email válido.');
        form.elements['email'].focus();
        return false;
    }

    if (comentario.length < 20) {
        alert('O comentário deve ter pelo menos 20 caracteres.');
        form.elements['comentario'].focus();
        return false;
    }

    for (var i = 0; i < pesquisa.length; i++) {
        if (pesquisa[i].checked) {
            pesquisaEscolhida = true;
            mensagem = (pesquisa[i].value === 'sim') 
                ? 'Volte sempre à está página!' 
                : 'Que bom que você voltou a visitar esta página!';
            break;
        }
    }

    if (!pesquisaEscolhida) {
        alert('Por favor, selecione uma opção na pesquisa.');
        return false;
    }

    document.getElementById('mensagem').innerText = mensagem;
    return false; 
}
