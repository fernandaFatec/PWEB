document.getElementById("cursoSelect").onchange = function () {
  var selectedCurso = this.value;
  if (selectedCurso !== "0") {
    var confirmar = confirm("Deseja abrir o curso selecionado?");
    if (confirmar) {
      abrirJanela(selectedCurso);
    }
  }
};

function abrirJanela(curso) {
  var cursoNome;
  switch (curso) {
    case "1":
      cursoNome = "Análise e Desenvolvimento de Sistemas";
      break;
    case "2":
      cursoNome = "Eletrônica Automotiva";
      break;
    case "3":
      cursoNome = "Fabricação Mecânica";
      break;
    case "4":
      cursoNome = "Gestão da Qualidade";
      break;
    case "5":
      cursoNome = "Logística";
      break;
    case "6":
      cursoNome = "Manufatura Avançada";
      break;
    case "7":
      cursoNome = "Polímeros";
      break;
    case "8":
      cursoNome = "Processos Metalúrgicos";
      break;
    case "9":
      cursoNome = "Projetos Mecânicos";
      break;
    case "10":
      cursoNome = "Sistemas Biomédicos";
      break;
    default:
      cursoNome = "Curso não especificado";
      break;
  }

  var newWindow = window.open("", "Curso", "width=600,height=300");
  newWindow.document.write("<h1>" + cursoNome + "</h1>");
  newWindow.document.write(
    "<p>Algumas informações sobre o curso " + cursoNome + "...</p>"
  );
  newWindow.document.close();
}
