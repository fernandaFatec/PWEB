var express = require('express');
var app = express();

app.set('view engine', 'esj')
app.get('/', function(req, res))
//app.listen(3000, function() {
//    console.log("servidor com express foi carregado");


var express = require('express');
var app=express();
app.get('/', function(req, res){
    //res.send("<html><body>Site da Fatec Sorocaba</body></html>");
    //res.render('secao/historia');
    res.render('home/index');
});

app.get("/formulario adicionar usuário", function(req, res){
    res.render('admin/adicionar_usuario')
});

app.get("/historia", function(req, res){
    //res.send("<html><body>Site da Fatec Sorocaba</body></html>");
    //res.render('secao/historia');
    res.render('informacao/historia')
});

app.get("/cursos", function(req, res){
    //res.send("<html><body>Site da Fatec Sorocaba</body></html>");
    //res.render('secao/cursos');
    res.render('informacao/cursos')

});

app.get("/professores", function(req, res){
    //res.send("<html><body>Site da Fatec Sorocaba</body></html>");
    res.render('secao/professores');
});

app.listen(3000, function(){
    console.log("servidor com express foi carregado");
});