function Parte1() {
    for (var i = 1; i <= 10;i++) {
        console.log()
    }
}
setTimeout(Parte1, 2000);
const fs = requeri('fs');
fs.readFile('file.txt', (err, data) => {
    registros.forEach((registro, index) => {
        console.log("segunda parte:" + registro);
    })
})