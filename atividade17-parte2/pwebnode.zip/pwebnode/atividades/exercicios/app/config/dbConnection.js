module.exports = function() {
    const config = {
        user: 'LOGON',
        password: 'senha',
        database: 'site_fatec',
        server: 'nome_do_servidor',
        driver: 'msnodesqlv8',
    }
    return sql.connect(config);

}