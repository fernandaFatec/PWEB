module.exports = function(app) {
    app.get('/informacao/professores', function(req,res){
 
        const sql = require('mssql');
        const sqlConfig = {
            user: "BD2111029",
            password: "Fatec@123",
            server: "apolo",
            database: "BD",
            options: {
                encrypt: false,
                trustServerCertificate: true
            }            
        }
 
        async function getProfessores() {
            try {
                const pool = await sql.connect(sqlConfig);
 
                const results = await pool.request().query('SELECT * FROM PROFESSORES');
 
                res.render('/informacao/professores', {profs: results.recordsets});
            } catch (err) {
                console.log("ERRO: " + err)
            }            
        }
 
        getProfessores();
    });
}