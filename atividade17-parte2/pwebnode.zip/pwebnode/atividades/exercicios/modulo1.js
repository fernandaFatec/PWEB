var texto = "observe que essa mensagem vem do módulos";

module.exports = texto;