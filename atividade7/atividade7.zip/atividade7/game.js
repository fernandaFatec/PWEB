document.getElementById("jogarBtn").addEventListener("click", jogar);

function jogar() {
    var opcao = parseInt(prompt("Escolha sua opção:  1 - Papel | 2 - Pedra | 3 - Tesoura"));
    var resposta = Math.floor(Math.random() * 3); // Retorna um número aleatório entre 0 e 2
    var voceEscolheu = "";

    switch(opcao) {
        case 1:
            voceEscolheu = "Papel";
            break;
        case 2:
            voceEscolheu = "Pedra";
            break;
        case 3:
            voceEscolheu = "Tesoura";
            break;
        default:
            alert("Opção inválida. Por favor, escolha 1 para Papel, 2 para Pedra ou 3 para Tesoura.");
            return;
    }

    var opcoes = ["Papel", "Pedra", "Tesoura"];
    var computadorEscolheu = opcoes[resposta];

    if (opcao === resposta + 1) {
        alert("Empate. Você escolheu " + voceEscolheu + " e o computador escolheu " + computadorEscolheu + ".");
    } else if ((opcao === 1 && resposta === 2) || (opcao === 2 && resposta === 3) || (opcao === 3 && resposta === 0)) {
        alert("Você ganhou. " + voceEscolheu + " vence " + computadorEscolheu + ".");
    } else {
        alert("Você perdeu. " + computadorEscolheu + " vence " + voceEscolheu + ".");
    }
}
