var idades = [];
var opinioes = [];
var generos = [];

function enviarFormulario() {
  var idade = parseInt(document.getElementById('age').value);
  var opiniao = parseInt(document.getElementById('opinion').value);
  var genero = document.getElementById('gender').value;

  idades.push(idade);
  opinioes.push(opiniao);
  generos.push(genero);

  document.getElementById('result').innerHTML = calcularResultados();
}

function calcularResultados() {
  var totalPessoas = idades.length;
  var mediaIdade = calcularMedia(idades);
  var idadeMaisVelha = encontrarMaisVelha(idades);
  var idadeMaisNova = encontrarMaisNova(idades);
  var opinioesPessimas = contarOpinioesPessimas(opinioes);
  var opinioesBoas = contarOpinioesBoas(opinioes);
  var percentualOpinioesBoas = calcularPercentualOpinioesBoas(opinioesBoas, totalPessoas);
  var quantidadeHomens = contarGenero(generos, 'masculino');
  var quantidadeMulheres = contarGenero(generos, 'feminino');

  return (
    "Média de idade: " + mediaIdade + "<br>" +
    "Idade mais velha: " + idadeMaisVelha + "<br>" +
    "Idade mais nova: " + idadeMaisNova + "<br>" +
    "Pessoas que responderam péssimo: " + opinioesPessimas + "<br>" +
    "Porcentagem de pessoas que responderam ótimo e bom: " + percentualOpinioesBoas + "%<br>" +
    "Número de homens: " + quantidadeHomens + "<br>" +
    "Número de mulheres: " + quantidadeMulheres
  );
}

function calcularMedia(arr) {
  var soma = 0;
  for (var i = 0; i < arr.length; i++) {
    soma += arr[i];
  }
  return (soma / arr.length).toFixed(2);
}

function encontrarMaisVelha(arr) {
  var maisVelha = arr[0];
  for (var i = 1; i < arr.length; i++) {
    if (arr[i] > maisVelha) {
      maisVelha = arr[i];
    }
  }
  return maisVelha;
}

function encontrarMaisNova(arr) {
  var maisNova = arr[0];
  for (var i = 1; i < arr.length; i++) {
    if (arr[i] < maisNova) {
      maisNova = arr[i];
    }
  }
  return maisNova;
}

function contarOpinioesPessimas(arr) {
  var contador = 0;
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] === 1) {
      contador++;
    }
  }
  return contador;
}

function contarOpinioesBoas(arr) {
  var contador = 0;
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] >= 3) {
      contador++;
    }
  }
  return contador;
}

function calcularPercentualOpinioesBoas(opinioesBoas, totalPessoas) {
  return ((opinioesBoas / totalPessoas) * 100).toFixed(2);
}

function contarGenero(arr, genero) {
  var contador = 0;
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] === genero) {
      contador++;
    }
  }
  return contador;
}
