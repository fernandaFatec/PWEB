function calcularIMC() {
    var altura = parseFloat(document.getElementById('altura').value);
    var peso = parseFloat(document.getElementById('peso').value);
    
    var imc = peso / (altura * altura);
    var classificacao = '';
    var grau = '';
  
    if (imc < 18.5) {
      classificacao = 'magreza';
      grau = '0';
    } else if (imc >= 18.5 && imc < 25) {
      classificacao = 'normal';
      grau = '0';
    } else if (imc >= 25 && imc < 30) {
      classificacao = 'sobrepeso';
      grau = 'I';
    } else if (imc >= 30 && imc < 40) {
      classificacao = 'obesidade';
      grau = 'II';
    } else {
      classificacao = 'obesidade grave';
      grau = 'III';
    }
  
    var resultado = 'IMC: ' + imc.toFixed(2) + ' | Classificação: ' + classificacao + ' | Grau: ' + grau;
    document.getElementById('resultado').innerText = resultado;
  }
  
  document.getElementById('calculadora').addEventListener('submit', function(e) {
    e.preventDefault();
    calcularIMC();
  });
