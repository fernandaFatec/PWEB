let alunos = [];

function adicionarAluno() {
  const nome = document.getElementById("nome").value.trim();
  const ra = document.getElementById("ra").value.trim();
  const nota1 = parseFloat(document.getElementById("nota1").value);
  const nota2 = parseFloat(document.getElementById("nota2").value);
  const nota3 = parseFloat(document.getElementById("nota3").value);

  if (nome === "" || !nome.includes(" ")) {
    alert("Nome inválido. Por favor, insira o nome completo.");
    return;
  }
  if (!/^\d{5}$/.test(ra)) {
    alert("RA inválido. Deve conter 5 dígitos numéricos.");
    return;
  }
  if (
    isNaN(nota1) ||
    isNaN(nota2) ||
    isNaN(nota3) ||
    nota1 < 0 ||
    nota1 > 10 ||
    nota2 < 0 ||
    nota2 > 10 ||
    nota3 < 0 ||
    nota3 > 10
  ) {
    alert("Notas inválidas. Devem estar entre 0 e 10.");
    return;
  }

  const media = (nota1 + nota2 + nota3) / 3;

  alunos.push({ nome, ra, media });

  atualizarListaAlunos();

  document.getElementById("nome").value = "";
  document.getElementById("ra").value = "";
  document.getElementById("nota1").value = "";
  document.getElementById("nota2").value = "";
  document.getElementById("nota3").value = "";
}

function atualizarListaAlunos() {
  const listaAlunos = document.getElementById("alunos-list");
  listaAlunos.innerHTML = "";
  alunos.forEach((aluno) => {
    const alunoInfo = document.createElement("div");
    alunoInfo.innerHTML = `<strong>Nome:</strong> ${
      aluno.nome
    } | <strong>RA:</strong> ${
      aluno.ra
    } | <strong>Média:</strong> ${aluno.media.toFixed(2)}`;
    listaAlunos.appendChild(alunoInfo);
  });

  const mediaGeral =
    alunos.reduce((acc, aluno) => acc + aluno.media, 0) / alunos.length;
  document.getElementById(
    "media-geral"
  ).innerText = `Média Geral: ${mediaGeral.toFixed(2)}`;
}
